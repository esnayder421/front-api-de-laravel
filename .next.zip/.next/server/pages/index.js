"use strict";
(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 9241:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_index_js__WEBPACK_IMPORTED_MODULE_0__.Z)
/* harmony export */ });
/* harmony import */ var private_next_pages_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5901);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_index_js__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_index_js__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ GLOBAL)
/* harmony export */ });
const GLOBAL = {
    "urlApi": "https://loginlaravel.softwaremys.site/api",
    "ruteMorty": "https://rickandmortyapi.com/api/character?page=",
    "urlFront": "http://localhost:3000/"
};


/***/ }),

/***/ 5901:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Home)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _profile_services_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(802);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _profile_services_endPoint__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9817);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_profile_services_auth__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_4__, _profile_services_endPoint__WEBPACK_IMPORTED_MODULE_6__]);
([_profile_services_auth__WEBPACK_IMPORTED_MODULE_3__, js_cookie__WEBPACK_IMPORTED_MODULE_4__, _profile_services_endPoint__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







// Sweet alert

function Home() {
    // const cookies = new Cookies();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const [viewAuth, setViewAuth] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleSbmit = async (e)=>{
        e.preventDefault();
        try {
            const email = e.target.email.value;
            const password = e.target.password.value;
            const response = await (0,_profile_services_auth__WEBPACK_IMPORTED_MODULE_3__/* .auth */ .I)({
                email,
                password
            });
            // cookies.set('token', response.access_token, { path: '/' });
            js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].set("token", response.access_token, {
                expires: 7,
                path: "/"
            });
            if (response) {
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().resumeTimer));
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: "Inicio de Sesion exitoso!"
                });
                router.push("/profile/Profile");
            }
        } catch (error) {
            const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast)=>{
                    toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().stopTimer));
                    toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().resumeTimer));
                }
            });
            Toast.fire({
                icon: "error",
                title: "Credenciales no validas!"
            });
            console.log(error);
        }
    };
    const handleRegister = async (e)=>{
        e.preventDefault();
        try {
            const name = e.target.name.value;
            const email = e.target.email.value;
            const password = e.target.password.value;
            const response = await (0,_profile_services_endPoint__WEBPACK_IMPORTED_MODULE_6__/* .register */ .z2)({
                name,
                email,
                password
            });
            if (response) {
                const Toast = sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().mixin({
                    toast: true,
                    position: "top-end",
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true,
                    didOpen: (toast)=>{
                        toast.addEventListener("mouseenter", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().stopTimer));
                        toast.addEventListener("mouseleave", (sweetalert2__WEBPACK_IMPORTED_MODULE_7___default().resumeTimer));
                    }
                });
                Toast.fire({
                    icon: "success",
                    title: "Registro Exitoso!"
                });
                setViewAuth(false);
            }
        } catch (error) {
            console.log(error);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "container ",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: "",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "container-fluid h-custom",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "row d-flex justify-content-center align-items-center vh-100",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: "col-md-9 col-lg-6 col-xl-5",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
                                src: "https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.webp",
                                className: "img-fluid",
                                alt: "Sample image"
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "col-md-8 col-lg-6 col-xl-4 offset-xl-1",
                            children: [
                                !viewAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleSbmit,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "divider d-flex align-items-center my-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-center fw-bold  mb-0",
                                                children: "Inicio de sesion"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-outline mb-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "email",
                                                    className: "form-control form-control-lg",
                                                    placeholder: "Ingrese su correo electronico",
                                                    name: "email"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "form-label",
                                                    children: "Correo electronico"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-outline mb-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "password",
                                                    id: "form3Example4",
                                                    className: "form-control form-control-lg",
                                                    placeholder: "Ingrese una contrase\xf1a",
                                                    name: "password"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "form-label",
                                                    children: "Contrase\xf1a"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-center text-lg-start mt-2 pt-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "submit",
                                                    className: "btn btn-primary btn-lg",
                                                    style: {
                                                        paddingLeft: "2.5rem",
                                                        paddingRight: "2.5rem"
                                                    },
                                                    children: "Iniciar sesion"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "small fw-bold  pt-1 mb-0",
                                                    children: [
                                                        "No tienes cuenta?",
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            className: "btn btn-link",
                                                            onClick: ()=>setViewAuth(true),
                                                            children: "Registro"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                viewAuth && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleRegister,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "divider d-flex align-items-center my-4",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                                className: "text-center fw-bold  mb-0",
                                                children: "Registro"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-outline mb-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "text",
                                                    className: "form-control form-control-lg",
                                                    placeholder: "Ingrese su nombre completo",
                                                    name: "name"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "form-label",
                                                    children: "Nombre completo"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-outline mb-4",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "email",
                                                    className: "form-control form-control-lg",
                                                    placeholder: "Ingrese su correo electronico",
                                                    name: "email"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "form-label",
                                                    children: "Correo electronico"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "form-outline mb-3",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                    type: "password",
                                                    id: "form3Example4",
                                                    className: "form-control form-control-lg",
                                                    placeholder: "Ingrese una contrase\xf1a",
                                                    name: "password"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                    className: "form-label",
                                                    children: "Contrase\xf1a"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "text-center text-lg-start mt-4 pt-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    type: "submit",
                                                    className: "btn btn-primary btn-lg",
                                                    style: {
                                                        paddingLeft: "2.5rem",
                                                        paddingRight: "2.5rem"
                                                    },
                                                    children: "Registrarme"
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                                    className: "small fw-bold  pt-1 mb-0",
                                                    children: [
                                                        "Ya tienes una cuenta?",
                                                        " ",
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                            className: "btn btn-link",
                                                            onClick: ()=>setViewAuth(false),
                                                            children: "Inicia sesion"
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 802:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ auth)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var models_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const url_global = models_model__WEBPACK_IMPORTED_MODULE_1__/* .GLOBAL.urlApi */ .a.urlApi;
const auth = async (credentials)=>{
    const url = url_global + "/auth/login";
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, credentials);
    // console.log(response.data.access_token)
    return response.data;
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ai": () => (/* binding */ getProfile),
/* harmony export */   "ck": () => (/* binding */ updateProfile),
/* harmony export */   "z2": () => (/* binding */ register)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var models_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const url_global = models_model__WEBPACK_IMPORTED_MODULE_1__/* .GLOBAL.urlApi */ .a.urlApi;
const register = async (data)=>{
    const url = url_global + "/users";
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, data);
    return response;
};
const getProfile = async (token)=>{
    const url = url_global + "/auth/me";
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, {}, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return response.data;
};
const updateProfile = async (token, data, id)=>{
    const url = url_global + "/users/" + id;
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].put(url, data, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    console.log(response);
// return response.data
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 1109:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 7782:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 9915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893,664], () => (__webpack_exec__(9241)));
module.exports = __webpack_exports__;

})();