"use strict";
(() => {
var exports = {};
exports.id = 184;
exports.ids = [184];
exports.modules = {

/***/ 193:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* reexport safe */ private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__["default"]),
/* harmony export */   "getProfile": () => (/* reexport safe */ private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__.Ai),
/* harmony export */   "register": () => (/* reexport safe */ private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__.z2),
/* harmony export */   "updateProfile": () => (/* reexport safe */ private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__.ck)
/* harmony export */ });
/* harmony import */ var private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9817);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__]);
private_next_pages_profile_services_endPoint_js__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

        // Next.js Route Loader
        
        
    
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 648:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ GLOBAL)
/* harmony export */ });
const GLOBAL = {
    "urlApi": "https://loginlaravel.softwaremys.site/api",
    "ruteMorty": "https://rickandmortyapi.com/api/character?page=",
    "urlFront": "http://localhost:3000/"
};


/***/ }),

/***/ 9817:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Ai": () => (/* binding */ getProfile),
/* harmony export */   "ck": () => (/* binding */ updateProfile),
/* harmony export */   "z2": () => (/* binding */ register)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
/* harmony import */ var models_model__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const url_global = models_model__WEBPACK_IMPORTED_MODULE_1__/* .GLOBAL.urlApi */ .a.urlApi;
const register = async (data)=>{
    const url = url_global + "/users";
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, data);
    return response;
};
const getProfile = async (token)=>{
    const url = url_global + "/auth/me";
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post(url, {}, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    return response.data;
};
const updateProfile = async (token, data, id)=>{
    const url = url_global + "/users/" + id;
    const response = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].put(url, data, {
        headers: {
            Authorization: `Bearer ${token}`
        }
    });
    console.log(response);
// return response.data
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(193));
module.exports = __webpack_exports__;

})();